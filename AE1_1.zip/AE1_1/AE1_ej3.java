package AE1_1;

public class AE1_ej3 {

	public static void sumarPares(int[] args) {
		int numero = args[0];
		int sumatotal = 0;
		for(int i=0;i<=numero;i++) {
			if(numero%2==0) {
				sumatotal += numero;
			}
		}
		System.out.println("La suma es "+ sumatotal);
	}

}
