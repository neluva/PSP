package AE1_1;
;
public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(sayHello());
	}
	
	public static String sayHello() {
		return "Hola Mundo";
	}

}
