package AE1_1;
import java.util.Scanner;
public class AE1_ej7 {

	public static void main(String[] args) {
		
		String salario="";
		System.out.print("Introduce cuanto tiempo lleva usted en la empresa(si lleva menos de un a�o ponga 0)");
		Scanner scan1= new Scanner(System.in);
		int anyo= scan1.nextInt();
		Scanner scan2 = new Scanner(System.in);
		String nombre = scan2.nextLine();
		if(anyo >= 1 && anyo <=2) {
			salario = "Desarrollador Junior L2 � 18000-22000";
		}else if(anyo >=3 && anyo <5) {
			salario = "Desarrollador Senior L1 � 22000-28000";
		}else if(anyo>=5&&anyo<=8) {
			salario = "Desarrollador Senior L2 � 28000-36000";
		}else if(anyo>8){
			salario = "Analista / Arquitecto. Salario a convenir en base a rol";
		} else {
			salario = "Desarrollador Junior L1 � 15000-18000";
		
		}
		
		System.out.println(nombre+" tu sueldo es el relacionado con: "+salario);
	}
}
