package AE1_1;

public class AE1_ej5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int mayor = 0;
		int entero[] = new int[] {100,123,76,89,56,20};
		for(int i=0;i<entero.length;i++) {
			if(entero[i]>mayor) {
				mayor = entero[i];
			}
		}
		System.out.println("El numero mas alto es: "+mayor );
	}

}
