	package AE1_1;

public class AE1_ej4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double factorial =1;
		for(int i =1; i<=15;i++) {
			factorial = (factorial* i); 
		}
		System.out.println("El resultado del factorial de 15 es: "+factorial);
	}

}
