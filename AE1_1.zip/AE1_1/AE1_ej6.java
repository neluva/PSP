package AE1_1;
import java.util.Scanner;
public class AE1_ej6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] enteros = new int[]{};
		for(int i=0;i<=5;i++) {
			Scanner scan1 = new Scanner(System.in);
			enteros[i]=scan1.nextInt();
		}
		for(int i=(enteros.length-1);i<enteros.length;i--) {
			System.out.println(enteros[i]);
		}
		
		
	}

}
