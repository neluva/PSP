package AE1_1;
import java.util.Scanner;
public class AE1_ej8 {

	public static void main(String[] args) {
		int nummax, contador = 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Escribe el numero maximo:");
		nummax = sc.nextInt();
		for (int i = 1; i <= nummax; i++) {
			if (esPrimo(i)) {
				contador++;
				System.out.print(i+",");
			}
		}
		System.out.println("\nTotal: "+contador);
		sc.close();
	}

	public static boolean esPrimo(int numero) {
		if (numero == 0 || numero == 1 || numero == 4) {
			return false;
		}
		for (int i = 2; i< numero / 2; i++) {

			if (numero % i == 0)
				return false;
		}

		return true;
	}
}