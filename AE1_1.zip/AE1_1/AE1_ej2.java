package AE1_1;
import java.util.Scanner;
import java.util.ArrayList;
public class AE1_ej2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] alumnos = new String[6];
		for(int i =0; i<=6;i++) {
			Scanner scanName = new Scanner(System.in);
			alumnos[i] = scanName.nextLine();
		}
		for(int i = 0; i<=alumnos.length;i++) {
			System.out.println(alumnos[i]);
		}
		ArrayList<String> alumnado = new ArrayList<String>();
		for(int i =0;i<=6;i++) {
			Scanner scanAlumno = new Scanner(System.in);
			alumnado.add(scanAlumno.nextLine());
		}
		for(int i=0;i<=alumnado.size();i++) {
			System.out.println(alumnado.get(i));
		}
	}
		
}
